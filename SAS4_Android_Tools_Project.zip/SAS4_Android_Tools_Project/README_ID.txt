SAS4 Android Tools — proyek contoh Android Studio

ISI:
- Antarmuka Android dengan enam switch sesuai daftar fitur dari Cheat Table PC.
- Switch hanya demonstrasi UI; tidak mengubah game dan tidak mengakses memori proses lain.
- Tidak memerlukan root.

CARA MEMBUKA:
1. Ekstrak ZIP ini.
2. Buka Android Studio.
3. Pilih Open, lalu pilih folder "SAS4_Android_Tools_Project".
4. Tunggu Gradle Sync selesai.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Jika berhasil, Android Studio menampilkan lokasi APK untuk dipasang.

CATATAN:
- APK belum disertakan karena lingkungan pembuatan ini tidak memiliki Android SDK/Gradle untuk mengompilasi aplikasi.
- Ini adalah proyek sumber yang bisa dibuka dan dibangun di Android Studio.
- Fitur cheat dari Cheat Engine Windows tidak dikonversi atau diaktifkan oleh aplikasi ini.
