package com.example.sas4tools

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Switch
import android.widget.Toast

class MainActivity : Activity() {
    private val items = listOf(
        "No Reload",
        "Rapid Fire",
        "God Mode (Experimental)",
        "Infinite Energy",
        "Infinite Frag Grenades",
        "Infinite Cryo Grenades"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(Color.rgb(13, 20, 34))
        }

        val title = TextView(this).apply {
            text = "SAS4 ANDROID TOOLS"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "UI prototype • Android"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        root.addView(subtitle)

        val notice = TextView(this).apply {
            text = "DEMO ONLY\\nSwitch di bawah hanya mengubah tampilan aplikasi. Aplikasi ini tidak mengakses atau mengubah memori SAS 4."
            textSize = 14f
            setTextColor(Color.rgb(255, 224, 138))
            setBackgroundColor(Color.rgb(49, 43, 28))
            setPadding(16, 14, 16, 14)
        }
        root.addView(notice)

        items.forEach { name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 14, 8, 14)
                setBackgroundColor(Color.rgb(25, 36, 55))
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                params.topMargin = 12
                layoutParams = params
            }

            val label = TextView(this).apply {
                text = name
                textSize = 15f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val toggle = Switch(this).apply {
                text = " "
                setOnCheckedChangeListener { _, checked ->
                    Toast.makeText(
                        this@MainActivity,
                        if (checked) "$name: demo ON" else "$name: demo OFF",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            row.addView(label)
            row.addView(toggle)
            root.addView(row)
        }

        val footer = TextView(this).apply {
            text = "Tidak memerlukan root. Tidak terhubung ke game."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(footer)

        setContentView(root)
    }
}
